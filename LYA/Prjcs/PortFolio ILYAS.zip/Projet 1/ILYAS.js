


    function h(){

      /*document.getElementById("profil").style.top="-0.7rem";
      document.getElementById("mode1").style.top="0.35rem";
      document.getElementById("mode2").style.top="0.35rem";*/
            var home=document.getElementById("home").style.display="block" ;
            var pers=document.getElementById("pers").style.display="none" ;
            var prof=document.getElementById("prof").style.display="none" ;
            var cnt=document.getElementById("CNTact").style.display="none " ;
            var hm=document.getElementById("hmm") ;
            var pr=document.getElementById("prr") ;
            var prf=document.getElementById("prff") ;
            var tt=document.getElementById("ttt") ;
            var cntName=document.getElementById("cnt");
            hm.style.textShadow="5px 12px 25px white";
            pr.style.textShadow="none";
            prf.style.textShadow="none";
            tt.style.textShadow="none";
            cntName.style.textShadow="none";

        }



        function pe(){
           var pers=document.getElementById("pers").style.display="block" ;
           var home=document.getElementById("home").style.display="none" ;
           var prof=document.getElementById("prof").style.display="none" ;
           var cnt=document.getElementById("CNTact").style.display="none " ;
           var hm=document.getElementById("hmm") ;
           var pr=document.getElementById("prr") ;
           var prf=document.getElementById("prff") ;
           var tt=document.getElementById("ttt") ;
           var cntName=document.getElementById("cnt");
          /* document.getElementById("profil").style.top="-0.7rem";
           document.getElementById("mode1").style.top="0.2rem";
           document.getElementById("mode2").style.top="0.2rem";*/
                  pr.style.textShadow="5px 12px 25px white";
                  hm.style.textShadow="none";
                  prf.style.textShadow="none";
                  tt.style.textShadow="none";
                  cntName.style.textShadow="none";
        }

        function pr(){
           var prof=document.getElementById("prof").style.display="block" ;
           var pers=document.getElementById("pers").style.display="none" ;
           var home=document.getElementById("home").style.display="none" ;
           var cnt=document.getElementById("CNTact").style.display="none " ;
            var hm=document.getElementById("hmm") ;
            var prf=document.getElementById("prff") ;
              var pr=document.getElementById("prr") ;
              var tt=document.getElementById("ttt") ;
             /* document.getElementById("profil").style.top="-1.5rem";
              document.getElementById("mode1").style.top="-0.4rem";
              document.getElementById("mode2").style.top="-0.4rem";*/
              var cntName=document.getElementById("cnt");
                     pr.style.textShadow="none";
                     hm.style.textShadow="none";
                     prf.style.textShadow="5px 12px 25px white";
                     tt.style.textShadow="none";
                     cntName.style.textShadow="none";
        }

           function t(){
            /*document.getElementById("profil").style.top="-0.7rem";
            document.getElementById("mode1").style.top="0.2rem";
            document.getElementById("mode2").style.top="0.2rem";
            document.getElementById("frc").style.top="0.1rem";*/
                  var prof=document.getElementById("prof").style.display="block" ;
                  var pers=document.getElementById("pers").style.display="block" ;
                  var cnt=document.getElementById("CNTact")
                  cnt.style.display="block " ;
                  //cnt.style.position="relative" ;
                    //                        cnt.style.top="0rem " ;
                  var home=document.getElementById("home").style.display="none" ;


                        var pr=document.getElementById("prr") ;
                          var hm=document.getElementById("hmm") ;
                                     var prf=document.getElementById("prff") ;
                                       var pr=document.getElementById("prr") ;
                                       var tt=document.getElementById("ttt") ;
                                       var cntName=document.getElementById("cnt");
                                              pr.style.textShadow="5px 12px 25px white";
                                              hm.style.textShadow="5px 12px 25px white";
                                              prf.style.textShadow="5px 12px 25px white";
                                              tt.style.textShadow="5px 12px 25px white";
                                              cntName.style.textShadow="5px 12px 25px white";
               }

               function Contact(){
                /*document.getElementById("profil").style.top="-1.5rem";
                document.getElementById("mode1").style.top="-0.35rem";
                document.getElementById("mode2").style.top="-0.35rem";*/
                var home=document.getElementById("home").style.display="none" ;
                          var pers=document.getElementById("pers").style.display="none" ;
                          var prof=document.getElementById("prof").style.display="none" ;
                          var cnt=document.getElementById("CNTact");
                          cnt.style.display="block " ;
                          var cntName=document.getElementById("cnt");
                           cnt.style.position="relative" ;
                          cnt.style.top="12rem " ;

                          var hm=document.getElementById("hmm") ;
                          var pr=document.getElementById("prr") ;
                          var prf=document.getElementById("prff") ;
                          var tt=document.getElementById("ttt") ;
                          cntName.style.textShadow="5px 12px 25px white"
                          pr.style.textShadow="none";
                          prf.style.textShadow="none";
                          tt.style.textShadow="none";


               }



function Active(){


  document.getElementById("car2").style.color="black";
  document.getElementById("car3").style.color="black";
  
for (let i=0 ;i<3;i++){
  document.getElementsByClassName("ptT")[i].style.color='black';
}


let c=document.getElementsByClassName("c1")
for (let i=0 ;i<c.length;i++){
c[i].style.color="black";
}
   var md1=document.getElementById("mode1");
    var bd=document.getElementsByTagName("body");
    var mn=document.getElementById("hmm");
    var tt=document.getElementById("ttt") ;
    var pr=document.getElementById("prr") ;
    var prf=document.getElementById("prff") ;
    //var fb=document.getElementById("f") ;
   // var inst=document.getElementById("ins");
   // var link=document.getElementById("in");
   // var wtsp=document.getElementById("wtspp");
   document.getElementById("firstBar").style.background="rgb(181, 214, 228)";
    var hmImage=document.getElementById("1");
    var prsImage=document.getElementById("2");
    var prfImage=document.getElementById("3");
    var ttImage=document.getElementById("4");
    var md2=document.getElementById("mode2");
    //var nxt=document.getElementById("nxt");
    // var back=document.getElementById("back");
     var det=document.getElementById("det");
     var grn=document.getElementsByClassName("detPrg");
     //document.getElementById("lglinkPC").src="C:/Users/pc/Pictures/me_files/in dr (2).png";
     var ContImage=document.getElementById("5").src="C:/Users/pc/Pictures/me_files/let lite  (2).png";
     var nmphn=document.getElementById("NamePhone").style.color="black";
     var detbtn=document.getElementById("detb").style.color= "black" ;
     var detbtn2=document.getElementById("detb2").style.color= "black" ;
     var inIM=document.getElementById("lglink").src="C:/Users/pc/Pictures/me_files/in dr (2).png" ;
      var infb=document.getElementById("lgfb").src="C:/Users/pc/Pictures/me_files/fb drk.png" ;
//var cntName=document.getElementById("cnt").style.color ="red";
     var inML=document.getElementById("lgmail").src="C:/Users/pc/Pictures/me_files/1.png" ;
      var iconsPhone=document.getElementsByClassName("11");
     //var ILlg=document.getElementById("profil").src="C:/Users/pc/Pictures/Saved Pictures/me_files/ilyas lttt4.png";
      var sk=document.getElementsByClassName("ktabaSk");
      for (let i=0 ; i<sk.length;i++){
        sk[i].style.color="black"
      }
     
      document.getElementById("car1").style.color="black";
     iconsPhone[0].src ="C:/Users/pc/Pictures/me_files/hm bl.png";
     iconsPhone[1].src ="C:/Users/pc/Pictures/me_files/prs lite.png";
     iconsPhone[2].src ="C:/Users/pc/Pictures/me_files/prf lite.png" ;
     iconsPhone[4].src ="C:/Users/pc/Pictures/me_files/tt lite.png";
     iconsPhone[3].src ="C:/Users/pc/Pictures/me_files/let lite  (2).png";
     iconsPhone[5].src =  "C:/Users/pc/Pictures/me_files/x (2).png"; 

     for (i=0; i<grn.length; i++){
       grn[i].style.background='linear-gradient(320deg ,  rgb(21, 78, 111) 0%,  rgb(69, 127, 161) 15% ,rgb(253, 253, 253)  100%)';
     }
     det.style.color="black";

     //grn.style.background = "white";
    //------------------------------------------------------
    ttImage.src="C:/Users/pc/Pictures/me_files/tt lite.png";
    prfImage.src="C:/Users/pc/Pictures/me_files/prf lite.png";
    hmImage.src="C:/Users/pc/Pictures/me_files/hm bl.png" ;
   prsImage.src="C:/Users/pc/Pictures/me_files/prs lite.png" ;
   // wtsp.style.color = "black" ;
   // link.style.color = "black" ;
    //inst.style.color = "black" ;
   // fb.style.color = "black" ;
    hmm.style.color = "red" ;
    pr.style.color = "red" ;
    prf.style.color = "red" ;
    tt.style.color = "red" ;
    /*hmm.style.textDecoration ="underline" ;
    pr.style.textDecoration ="underline" ;
    prf.style.textDecoration ="underline" ;
    tt.style.textDecoration ="underline" ;*/


    //___________________________________________
    document.body.style.color = "black";
    document.body.style.background = "#B3C7DA";
    md1.style.display="none";
    md2.style.display="block";
    //------------------------------------------
   nxt.src="C:/Users/pc/Pictures/me_files/next.png";
   back.src="C:/Users/pc/Pictures/me_files/back black.png" ;


    }



function Dative(){

  document.getElementById("car2").style.color="white";
  document.getElementById("car3").style.color="white";
  let c=document.getElementsByClassName("c1")
for (let i=0 ;i<c.length;i++){
c[i].style.color="white";
}
  for (let i=0 ;i<3;i++){
    document.getElementsByClassName("ptT")[i].style.color='white';
  }
  document.getElementById("car1").style.color="white";
  document.getElementById("firstBar").style.background="rgb(22, 33, 49)";
   var md1=document.getElementById("mode1");
   var md2=document.getElementById("mode2");
   var bd=document.getElementsByTagName("body");
       var mn=document.getElementById("hmm");
       var tt=document.getElementById("ttt") ;
       var pr=document.getElementById("prr") ;
       var prf=document.getElementById("prff") ;
     //  var fb=document.getElementById("f") ;
     //  var inst=document.getElementById("ins");
     //  var link=document.getElementById("in");
     //  var wtsp=document.getElementById("wtspp");
       var hmImage=document.getElementById("1");
       var prsImage=document.getElementById("2");
       var prfImage=document.getElementById("3");
       var ttImage=document.getElementById("4");
       var ContImage=document.getElementById("5").src="C:/Users/pc/Pictures/me_files/letter  (2).png";
       //var nxt=document.getElementById("nxt");
       //var back=document.getElementById("back");
       var det=document.getElementById("det");
       //var cntName=document.getElementById("cnt").style.color ="white";
       var nmphn=document.getElementById("NamePhone").style.color="white";
       var detbtn=document.getElementById("detb").style.color= "white" ;
         var grn=document.getElementsByClassName("detPrg");
         //var ILlg=document.getElementById("profil").src="C:/Users/pc/Pictures/me_files/lg ily lt (2).png";
         var inIM=document.getElementById("lglink").src="C:/Users/pc/Pictures/me_files/Sans titre (2).png" ;

         var inML=document.getElementById("lgmail").src="C:/Users/pc/Pictures/me_files/mail red (2).png" ;
         var infb=document.getElementById("lgfb").src="C:/Users/pc/Pictures/me_files/fb red.png" ;
               var iconsPhone=document.getElementsByClassName("11");
               var sk=document.getElementsByClassName("ktabaSk");
      for (let i=0 ; i<sk.length;i++){
        sk[i].style.color="white ";
      }
              iconsPhone[0].src ="C:/Users/pc/Pictures/me_files/hm (2).png";
              iconsPhone[1].src ="C:/Users/pc/Pictures/me_files/prf (2).png";
              iconsPhone[2].src ="C:/Users/pc/Pictures/me_files/dg (2).png" ;
              iconsPhone[3].src ="C:/Users/pc/Pictures/me_files/letter  (2).png";
              iconsPhone[4].src ="C:/Users/pc/Pictures/me_files/fl (2).png";
              iconsPhone[5].src =  "C:/Users/pc/Pictures/me_files/frm drk (2).png";
            for (i=0; i<grn.length; i++){
              grn[i].style.background=' linear-gradient(320deg ,  rgb(26, 26, 114) 0%,  rgb(7, 7, 55) 15% , rgb(0, 0, 0) 100%)';
            }
            det.style.color="white";
       //--------------------------------------------------------

       //-------------------------------------------------------
       //back.src="C:/Users/pc/Pictures/me_files/back red.png"
        //nxt.src="C:/Users/pc/Pictures/me_files/nxt red.png";
        ttImage.src="C:/Users/pc/Pictures/me_files/fl (2).png";
           prfImage.src="C:/Users/pc/Pictures/me_files/dg (2).png";
           hmImage.src="C:/Users/pc/Pictures/me_files/hm (2).png" ;
          prsImage.src="C:/Users/pc/Pictures/me_files/prf (2).png" ;
          //____________________________________________________________________
       document.body.style.color = "white";
        //wtsp.style.color = "white" ;
        //   link.style.color = "white" ;
        //   inst.style.color = "white" ;
        //   fb.style.color = "white" ;
           hmm.style.color = "white" ;
           pr.style.color = "white" ;
           prf.style.color = "white" ;
           tt.style.color = "white" ;
    md1.style.display="block";
    md2.style.display="none";
  document.body.style.background = "#15202B";
  //-----------------------------------------------------------------------
  hmm.style.textDecoration ="none" ;
      pr.style.textDecoration ="none" ;
      prf.style.textDecoration ="none" ;
      tt.style.textDecoration ="none" ;

      var detbtn2=document.getElementById("detb2").style.color= "white" ;




}
//_-_-_-_-_-_-_-_-_-_-_-_-_-_-_
  function pasNxt(){



    var ImgPrn=document.getElementById("cr1");
    var Img2=document.getElementById("cr2");
    var Img3=document.getElementById("cr3");
    Imgs=[Img2.src,ImgPrn.src,Img3.src];
    var tmp1=ImgPrn.src;
    var tmp2=Img2.src;

    ImgPrn.src=Img3.src ;
    Img2.src=tmp1 ;
    Img3.src=tmp2 ;
    //transition="2s";*/

  }


  function pasback(){
   var ImgPrn=document.getElementById("cr1");
      var Img2=document.getElementById("cr2");
      var Img3=document.getElementById("cr3");
      Imgs=[Img2.src,ImgPrn.src,Img3.src];

       var tmp1=ImgPrn.src;
          var tmp2=Img3.src;

          ImgPrn.src=Img2.src ;
          Img3.src=tmp1 ;
          Img2.src=tmp2 ;
  }



  function AffichDet(){


    const info = document.querySelector('#det1');
          info.classList.add('show');

    document.getElementById("detb").style.display ="none" ;
  }


  function ReduireDet(){
    const info = document.querySelector('#det1');
             info.classList.remove('show');
   document.getElementById("detb").style.display ="block" ;

  }

  function AffichPhoneMenu(){
  var mn=document.getElementById("menuPh").style.display="block" ;
  }

  function frmMenuPh(){
  var mn=document.getElementById("menuPh").style.display="none" ;
  }




function langueFRC(){

  document.getElementById("CarPartTit").innerHTML="Academic background";
document.getElementById("Im").innerHTML="I'm" ;
document.getElementById("detb").innerHTML="Show more details" ;
document.getElementById("detb2").innerHTML="Less details" ;
   /*document.getElementById("frc").src="C:/Users/pc/Pictures/me_files/france.jpg" ;*/
   document.getElementById("frc").style.display ="none ";
   document.getElementById("ENG").style.display ="block ";
   document.getElementById("hmm").innerHTML="Home" ;
   document.getElementById("prr").innerHTML="About" ;
   document.getElementById("prff").innerHTML="Professional";
   document.getElementById("ttt").innerHTML="All";
   document.getElementById("disc1").innerHTML= "Computer engineering student" ;
   document.getElementById("disc2").innerHTML= "National School of Applied Science Fez" ;
   var Cv=document.getElementsByClassName("cv");
   Cv[0].innerHTML="Download CV"
   document.getElementById( "car2Tit").innerHTML="National School of Applied Sciences of Fez   2020"
   document.getElementById( "car1Tit").innerHTML="Bacalaureat in Science Mathematics B    2019-2020";
   document.getElementById( "car3Tit").innerHTML="Computer Engineering Specialist 2022";
   document.getElementById("car3").innerHTML="I am currently pursuing my engineering education in Computer Engineering specialization at the National School of Applied Sciences in 2022. I chose this field because the concept of algorithms is one of the most interesting subjects for me. I have always been fascinated by the idea of breaking down a problem into iterations, as it reflects the mindset of mathematicians. With this training, I am now a Computer Engineering student and I am excited to apply the skills I have acquired in this exciting field.";
   document.getElementById("car2").innerHTML="I enrolled in the National School of Applied Sciences of Fez in 2020 to pursue my dream of becoming an engineer. After studying for two years in preparatory classes, I acquired the necessary foundations in mathematics, physics, mechanics, electronics, as well as languages. These prerequisite knowledge are essential in order to follow the specialty course that I have chosen. I am highly motivated and determined to give my best to succeed in this program and achieve my professional goal. I am convinced that the National School of Applied Sciences of Fes will provide me with the ideal academic environment to succeed."
   document.getElementById("txtper").innerHTML="ILYAS MAKHLOUL , Student of the National School of Applied Sciences of Fez, in Computer Engineering, I really like the future of WEB development as well as programming in general (C/C++, JAVA, JavaScript,..), I always like to use logic to find fast, precise and automatic solutions. to avoid repeating a task, and that's exactly the concept of algorithms, that's why I'm a Programmer ."
   document.getElementById("IP").innerHTML="Personal Information" ;
   document.getElementById("IP1").innerHTML="First and Last Name : Ilyas Makhloul";
   document.getElementById("IP2").innerHTML="Date of Birth: 17.10.2002";
   document.getElementById("CM").innerHTML="Skills";
   document.getElementById("titPrj").innerHTML="Project";
     document.getElementById("ctfPHONE").innerHTML="Certificates" ;
     //document.getElementById("nomCont").innerHTML="Name" ;
     //document.getElementById("big").innerHTML="Write a message" ;
      //document.getElementById("ENV").innerHTML="Send" ;
      document.getElementById("car1").innerHTML="I obtained a Bacalaureat in Science Mathematics B. I chose this major because I have always been passionate about mathematics and their real-world applications. Additionally, I aimed to develop my scientific mindset in preparation for a future career in engineering. This program allowed me to tackle complex challenges, solve difficult mathematical problems, and gain a solid understanding of fundamental scientific principles. Through this experience, I was able to build my confidence in my mathematical and scientific abilities, as well as my desire to pursue a career in applied science , so become engineer ."
      document.getElementsByClassName("ptT")[0].innerHTML='<strong>Game Development</strong>';
      document.getElementsByClassName("ptT")[1].innerHTML='<strong>Websites Development</strong> ';
      document.getElementsByClassName("ptT")[2].innerHTML='<strong>Application Development</strong>';
      document.getElementById("notDet1").innerHTML="I am a passionate game developer who has created several games using programming languages such as Java, C++, and JavaScript. Some of the games I have developed include the popular Snake game and the X-O puzzle game. Additionally, I have developed a wall-building game. These projects have allowed me to apply my programming, problem-solving, and game design skills. I worked hard to create fun, engaging, and playable games while ensuring accessibility for all players. These projects have strengthened my passion for game development and have pushed me to continue exploring new challenges in this exciting field.";
      document.getElementById("notDet2").innerHTML="I am passionate about developing websites, and I have worked on several projects to put my skills into practice. One of the most significant projects I have completed is my own portfolio, which I designed and developed myself. This website showcases my skills in website design and development. I dedicated a lot of time and effort to ensure that every detail was perfectly executed. I am proud of the final result, and I believe it demonstrates my commitment to excellence in website development.";
      document.getElementById("notDet3").innerHTML="I am passionate about application development and have gained extensive experience in this field. Over the years, I have created several innovative applications, but one of my greatest achievements is an application that converts voice into text paragraphs. This application is a remarkable technological feat that enables users to dictate their text and transform it into a readable and easily editable format. I am proud of this accomplishment and look forward to continuing to develop new applications that will enhance people's lives."
      //document.getElementByClassName("cnt").placeholder="Name" ;

}


function langueENG(){

  document.getElementById("CarPartTit").innerHTML="Parcours Académique ";
document.getElementById("frc").style.display ="block ";
document.getElementById("detb").innerHTML="Plus des détails" ;
document.getElementById("detb2").innerHTML="Moins de détails" ;
   document.getElementById("ENG").style.display ="none ";
   document.getElementById("hmm").innerHTML="Accueil" ;
      document.getElementById("prr").innerHTML="Personnelle" ;
      document.getElementById("prff").innerHTML="Professionnelle";
      document.getElementById("ttt").innerHTML="Tous";
       document.getElementById("disc1").innerHTML= "Etudiant Ingénieur en Génie Informatique" ;
         document.getElementById("disc2").innerHTML= "Ecole Nationale de Science Appliquée fés" ;
         var Cv=document.getElementsByClassName("cv");
            Cv[0].innerHTML="Télecharger CV" ;
            document.getElementById( "car2Tit").innerHTML="Ecole Nationale des Sciences Appliquées de  fés   2020"
            document.getElementById("car3").innerHTML="J'ai suivi ma formation Ingénieur en spécialité Génie Informatique à l'École Nationale des Sciences Appliquées en 2022. J'ai choisi cette filière car le concept d'algorithme est l'un des sujets les plus intéressants pour moi. J'ai toujours été fasciné par l'idée de diviser un problème en itérations, car cela reflète l'esprit des mathématiciens. Grâce à cette formation, je suis maintenant un étudiant en Ingénierie Informatique et j'ai hâte de mettre en pratique les compétences que j'ai acquises dans ce domaine passionnant."
            document.getElementById("txtper").innerHTML="ILYAS MAKHLOUL , Etudiant de l'ecole nationale de sciences appliquées de fes, en Génie Informatique, j'aime beaucoup le demaine de devlleppement WEB ainsi la programmation en génrale (C/C++, JAVA, JavaScript,..),J'ai toujours aimé d'utiliser la logique pour trouver des solutions rapides, précises et automatiques.pour éviter de repeter une tach , et c'est exactement le concept d'algorithmes ,c'est poour cela je suis Programmere . ";
            document.getElementById("IP").innerHTML="Information Personelle" ;
               document.getElementById("IP1").innerHTML="Nom et Prenom :Ilyas Makhloul";
               document.getElementById("IP2").innerHTML="Date de Naissance : 17.10.2002";
               document.getElementById("CM").innerHTML="Compétences";
               document.getElementById("titPrj").innerHTML="Projet";
                 document.getElementById("ctfPHONE").innerHTML="Les Certificats"
                 document.getElementById("Im").innerHTML="Je Suis" ;
                //  document.getElementById("nomCont").innerHTML="Nom" ;
                //  document.getElementById("big").innerHTML="Ecrire un Message" ;
                //  document.getElementById("ENV").innerHTML="Envoyer" ;
                  document.getElementById( "car1Tit").innerHTML="Baccalauréat en Science Mathématiques B  2019-2020";
                  document.getElementById("car1").innerHTML="J'ai obtenu un baccalauréat en Science Mathématiques B. J'ai choisi cette filière car j'ai toujours été passionné par les mathématiques et leur application dans le monde réel. En outre, j'avais pour objectif de développer mon esprit scientifique en vue d'une carrière future dans l'ingénierie. Cette filière m'a permis de relever des défis complexes, de résoudre des problèmes mathématiques difficiles et d'acquérir une solide compréhension des principes scientifiques fondamentaux. Grâce à cette expérience, j'ai pu renforcer ma confiance en mes capacités mathématiques et scientifiques, ainsi que mon désir de poursuivre une carrière en sciences appliquée, C'est à dire etre ingénieur ."
                  document.getElementById("car2").innerHTML="J'ai intégré l'école nationale des sciences appliquées de Fès en 2020 pour suivre mon rêve de devenir ingénieur. Après avoir étudié deux ans en classe préparatoire, j'ai acquis les bases nécessaires en mathématiques, physique, mécanique, électronique ainsi que des langues. Ces connaissances préalables sont indispensables pour pouvoir suivre le parcours en spécialité que j'ai choisi. Je suis très motivé et déterminé à donner le meilleur de moi-même pour réussir cette formation et réaliser mon objectif professionnel. Je suis convaincu que l'école nationale de science appliquée des Fès me fournira l'environnement académique idéal pour réussir."
                  document.getElementsByClassName("ptT")[0].innerHTML='<strong>Développement des jeux </strong> ';
      document.getElementsByClassName("ptT")[1].innerHTML='<strong>Développement des site webs</strong>';
      document.getElementsByClassName("ptT")[2].innerHTML='<strong>Développement des Applications</strong>';
      document.getElementById("notDet1").innerHTML="Je suis un développeur de jeux passionné qui a créé plusieurs jeux en utilisant des langages de programmation tels que Java,c++ et JavaScript. Parmi les jeux que j'ai développés figurent le célèbre jeu Snake et le jeu de réflexion X-O.aussi il y a le jeux de construction de mur, Ces projets m'ont permis de mettre en pratique mes compétences en programmation, en résolution de problèmes et en conception de jeux. J'ai travaillé dur pour créer des jeux amusants, engageants et jouables, tout en veillant à ce qu'ils soient accessibles à tous les joueurs. Ces projets ont renforcé ma passion pour le développement de jeux et m'ont poussé à continuer à explorer de nouveaux défis dans ce domaine passionnant.";
      document.getElementById("notDet2").innerHTML="Je suis un passionné de développement de sites web et j'ai travaillé sur plusieurs projets pour mettre mes compétences en pratique. Parmi les projets les plus importants que j'ai réalisés figure mon propre portfolio, que j'ai conçu et développé moi-même. Ce site web est une vitrine de mes compétences en matière de conception et de développement de sites web. J'y ai consacré beaucoup de temps et d'efforts pour m'assurer que chaque détail est parfaitement exécuté. Je suis fier du résultat final et je pense que cela montre mon engagement envers l'excellence en matière de développement de sites web";
      document.getElementById("notDet3").innerHTML= "Je suis passionné par le développement d'applications et j'ai acquis une grande expérience dans ce domaine. J'ai créé plusieurs applications innovantes au fil des années, mais l'une de mes plus grandes réalisations est une application qui transforme la voix en paragraphes textuels. Cette application est une véritable prouesse technologique qui permet aux utilisateurs de dicter leur texte et de le transformer en un format lisible et facilement éditable. Je suis fier de cette réalisation et je suis impatient de continuer à développer de nouvelles applications qui amélioreront la vie des gens";
    }

//_-_-_-_-_-_-_-__-_-_-_-_-_-_-__-_-_-_-_-_-_-__-_-_-_-_-_-_-__-_-_-_-_-_-_-__-_-_-_-_-_-_-_

document.getElementsByClassName("ptT")[0].style.borderLeft="6px solid red"  
document.getElementsByClassName("ptT")[0].style.fontSize="1.3rem" ; 

document.getElementsByClassName("ptT")[1].style.borderLeft="none"  
document.getElementsByClassName("ptT")[1].style.fontSize="1rem" 

document.getElementsByClassName("ptT")[2].style.borderLeft="none"  
document.getElementsByClassName("ptT")[2].style.fontSize="1rem" ; 


//document.getElementsById("notDet").style.display="block";

document.querySelector('#notDet1').classList.add('show');
document.querySelector('#notDet2').classList.remove('show');
_-_-_-_-_-_-_-__-_-_-_-_-_-_-__-_-_-_-_-_-_-__-_-_-_-_-_-_-__-_-_-_-_-_-_-__-_-_-_-_-_-_-_

function games(){
  document.getElementsByClassName("ptT")[0].style.borderLeft="6px solid red"  
  document.getElementsByClassName("ptT")[0].style.fontSize="1.3rem" ; 

  document.getElementsByClassName("ptT")[1].style.borderLeft="none"  
  document.getElementsByClassName("ptT")[1].style.fontSize="1rem" 
  
  document.getElementsByClassName("ptT")[2].style.borderLeft="none"  
  document.getElementsByClassName("ptT")[2].style.fontSize="1rem" ; 


  //document.getElementsById("notDet").style.display="block";

  document.querySelector('#notDet1').classList.add('show');
  document.querySelector('#notDet2').classList.remove('show');
  document.querySelector('#notDet3').classList.remove('show');

  //const info = document.querySelector('#det1');
  //           info.classList.remove('show');
  // document.getElementById("detb").style.display ="block" ;
}

function Sites(){
  document.getElementsByClassName("ptT")[1].style.borderLeft="6px solid red"  
  document.getElementsByClassName("ptT")[1].style.fontSize="1.3rem" ; 

  document.getElementsByClassName("ptT")[0].style.borderLeft="none"  
  document.getElementsByClassName("ptT")[0].style.fontSize="1rem" ; 

  document.getElementsByClassName("ptT")[2].style.borderLeft="none"  
  document.getElementsByClassName("ptT")[2].style.fontSize="1rem" ; 

  document.querySelector('#notDet2').classList.add('show');
  document.querySelector('#notDet1').classList.remove('show');
  document.querySelector('#notDet3').classList.remove('show');

}


function Apps() {
  document.getElementsByClassName("ptT")[2].style.borderLeft="6px solid red"  
  document.getElementsByClassName("ptT")[2].style.fontSize="1.3rem" 

  document.getElementsByClassName("ptT")[1].style.borderLeft="none"  
  document.getElementsByClassName("ptT")[1].style.fontSize="1rem" ; 

  document.getElementsByClassName("ptT")[0].style.borderLeft="none"  
  document.getElementsByClassName("ptT")[0].style.fontSize="1rem" ; 


  document.querySelector('#notDet1').classList.remove('show');
  document.querySelector('#notDet2').classList.remove('show');
  document.querySelector('#notDet3').classList.add('show');

}






function sc1(){
  document.querySelector('#scr1').classList.add('show');
  document.querySelector('#waaw').classList.add('show');

}