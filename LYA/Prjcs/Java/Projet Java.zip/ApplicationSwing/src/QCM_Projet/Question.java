package QCM_Projet;

public class Question {

	  String question;
	  String A ; 
	  String B ; 
	  String C;
	  String D ;
	  String correction ;
	  //-------------------------------------
	public Question(String question, String a, String b, String c, String d, String correction) {
		super();
		this.question = question;
		A = a;
		B = b;
		C = c;
		D = d;
		this.correction = correction;
	} 
	//---------------------------------------
	  
	}

